# Asian Peptide Manufacturers and Independent Laboratory Landscape — Supplier Prequalification and Supply-Chain Due Diligence


**Decision date:** **20 August 2026**  
**Prepared for:** South African therapeutic-supply due diligence  
**Universe:** 10 manufacturers/CDMOs and 4 independent laboratories in Asia  
**Document status:** Decision-grade public-evidence prequalification screen; **not** a final supplier approval, GMP certification, safety conclusion, product registration, or authorization to import, manufacture, distribute, test, release, or sell in South Africa.


> **Regulatory warning and scope.** No manufacturer or laboratory in this report is described as fully compliant, safe, or approved for South Africa. No public SAHPRA product registration, site recognition, or dossier linkage was established for any proposed peptide chain. A foreign regulator inspection, an establishment registration, a DMF, a CEP, a WHO listing, a laboratory accreditation, or a third-party passing result is not interchangeable with SAHPRA authorization or with product-, site-, activity-, method- and batch-specific qualification. This report excludes grey-market, research-use-only, cosmetic, retail, brokered and compounding sources and provides no medical dosing or regulatory-bypass guidance.


## 1. Executive summary

The public record supports a **controlled RFI and audit programme**, not an immediate award. **ScinoPharm Taiwan** is the only Tier A screening candidate, scoring 79/100 because current TFDA evidence connects its Tainan site to peptide APIs, sterile injectable activities and cold-chain GDP, while an FDA-regulated marketed glatiramer prefilled-syringe product provides a strong outcome signal.[^SCINO-TFDA-API][^SCINO-TFDA-STERILE][^SCINO-LABEL] Tier A means first-priority diligence only. Historical FDA records, current inspection classifications, product/site genealogy, sterile-assurance evidence, raw-material origins, subcontractors and a South African regulatory route remain unresolved.

The other nine manufacturers are Tier B. **Hybio** has unusually strong product-linked US and Chinese evidence but remains below Tier A because of unresolved quality-event remediation, current-certificate gaps and an opaque pen/device chain.[^HYBIO-LABEL][^HYBIO-FDA] **Piramal Turbhe** has valuable WHO-prequalified oxytocin and carbetocin API evidence, but its 2025 FDA VAI and six-observation Form 483 make cleaning, deviation, documentation and temperature-control CAPA effectiveness gating issues.[^PIR-WHO-OXY][^PIR-WHO-CAR][^PIR-483] **WuXi** has exceptional claimed peptide scale and end-to-end capability but incomplete public inspection packages, South Africa-specific logistics gaps and material China/geopolitical concentration.[^WUXI-INSPECT][^WUXI-FDA]

No independent laboratory is ready for automatic routine peptide batch-release reliance. **Vimta** is the strongest first RFI candidate because its WHO-prequalified laboratory status and site-specific systems evidence are comparatively substantive, although its 2023 FDA VAI, missing accreditation annex and several method gaps must be resolved.[^VIMTA-WHO][^VIMTA-NABL] **SGS Shanghai** and **Eurofins Kyoto/Kobe** are credible specialist candidates, especially for selected chemistry, microbiology, sterility, E&L, CCI or stability work, subject to exact-site and exact-method qualification.[^SGS-FDA][^EURO-PMDA][^EURO-483] **Intertek Mumbai** is Tier C for release-testing purposes because its currently verified ISO/IEC 17025 scope is environmental rather than pharmaceutical; it should not be the sole independent release laboratory without primary pharmaceutical licences and method scope.[^INTERTEK-IAS]

The immediate decision should be to issue product-specific RFIs to **ScinoPharm, Hybio, Piramal, WuXi and one API-focused comparator selected by molecule**; initiate laboratory RFIs with **Vimta, SGS and Eurofins**; keep Intertek limited to a possible specialist research role; and prohibit purchase commitments until the legal manufacturer, every physical site, registered dossier chain, raw-material genealogy, testing/release chain, sterile/device responsibilities and South Africa lane are fixed contractually.

## 2. Method, evidence rules and tier logic

The assessment combines the discovery screen, ten manufacturer dossiers, four laboratory dossiers and the structured findings supplied for this decision. Evidence was weighted in the following order: regulator, government, accreditation-body or product-label evidence; audited issuer filings and exchange disclosures; independently traceable public records; then supplier marketing. Marketing scale, capacity, inspection and accreditation claims are labelled **unverified** until supported by primary documents. When evidence could not be established, the report uses **Unknown** rather than inferring customers, countries, sites, equipment, certificates or performance.

The scoring model is a reproducible triage device. It does not predict future compliance and is not a substitute for an audit or regulatory assessment. Scores are capped by the evidence actually available publicly. **Tier A** requires at least 75 points and no critical unresolved public red flag; **Tier B** covers 55–74 points or a potentially remediable gap; **Tier C** is below 55 or unsuitable for the proposed role. A later discovery of an OAI classification, unresolved import ban, fabricated data, undisclosed critical subcontracting, licence mismatch or inability to provide complete raw records overrides the numeric result.


| Criterion | Weight | Public-evidence scoring interpretation |
|---|---:|---|
| Regulatory/site evidence | 25 | Exact legal entity and address, current licences/certificates, regulator inspections, product/site scope, primary records and closure status. |
| Peptide capability | 20 | Therapeutic GMP API/DS evidence; applicable synthesis, purification, isolation and scale; sterile DP/device capabilities scored only when separately evidenced. |
| Analytical/data integrity | 15 | Peptide control strategy, validation, reference standards, OOS/OOT/CAPA, audit trails, raw-data governance, sterility assurance where relevant. |
| Regulated-market/export evidence | 15 | Named product/dossier/label/CEP/WHO linkage is stronger than establishment registration, DMF filing or generic export claims. |
| Resilience/traceability | 15 | Site/train redundancy, raw-material genealogy, dual sources, subcontractor visibility, cold-chain/GDP, alternate lanes and continuity rights. |
| Transparency/adverse-history response | 10 | Timely disclosure, complete inspection packages, root cause, CAPA effectiveness, recurrence prevention and absence of contradictory claims. |


## 3. Supply-level distinctions

Qualification must be split into distinct supply levels. **Research, catalogue, non-GMP and pilot material** is never acceptable for therapeutic manufacture merely because the same corporate group operates a GMP site. **Starting materials and building blocks** require origin, manufacturer, synthetic route, impurity and change-control visibility but are not themselves evidence of GMP peptide API. **Peptide API/drug substance** requires an exact licensed legal entity, site, building/train, registered process, validated purification/isolation, release laboratory and retest/storage conditions. **Sterile drug product/fill-finish** adds contamination-control strategy, aseptic process simulation, environmental monitoring, sterilization/depyrogenation, container-closure integrity, particles and extractables/leachables. **Combination device and final packaging** add component manufacturers, ISO/device controls, assembly, human-factors, serialization and final release. Bulk API lyophilization is not sterile vial lyophilization; filling a PFS or cartridge does not by itself establish final pen/autoinjector assembly.

A qualification decision is therefore written as a tuple—**product + legal entity + physical site + building/line + process + dosage form + container/device + test/release sites + registered markets + transport lane**—and not as approval of a corporate brand.

## 4. Comparative manufacturer matrix and transparent scores

| ID | Manufacturer | Country | Principal proposed scope | Reg 25 | Pep 20 | Analyt/DI 15 | Market 15 | Resilience 15 | Transparency 10 | Total | Tier | Decision |

|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|---|---|

| M01 | **WuXi TIDES / WuXi STA (WuXi AppTec)** | China | API/DS; separate sterile DP/fill-finish | 19 | 19 | 11 | 12 | 6 | 5 | **72** | **B** | Enhanced RFI and separate API-versus-fill-finish audits; no award. |

| M02 | **Sinopep-Allsino Biopharmaceutical Co., Ltd.** | China | API/DS strongest; sterile DP conditional; no device qualification | 16 | 18 | 9 | 10 | 6 | 3 | **62** | **B** | Enhanced RFI focused on API; governance remediation and raw-data audit are gates. |

| M03 | **Hybio Pharmaceutical Co., Ltd.** | China | API/DS plus evidenced sterile/prefilled DP chain | 21 | 19 | 10 | 14 | 6 | 3 | **73** | **B** | Priority enhanced RFI; audit API and sterile/device chain separately. Tier B because adverse-history closure and current certificates are unresolved. |

| M04 | **CPC Scientific / Medtide (Hangzhou)** | China | API/DS only on public evidence | 15 | 18 | 10 | 12 | 5 | 3 | **63** | **B** | RFI only; full 2024/2026 FDA packages and remediation effectiveness are hard gates. |

| M05 | **Piramal Pharma Solutions, Turbhe** | India | API/DS; Turbhe is not evidenced as sterile DP | 21 | 17 | 9 | 13 | 6 | 4 | **70** | **B** | Priority RFI for WHO-backed products; require FDA CAPA effectiveness and lane challenge before audit closure. |

| M06 | **Shilpa Pharma Lifesciences / Shilpa Medicare** | India | API/DS; sterile DP not peptide-qualified and enforcement-affected | 17 | 16 | 8 | 11 | 6 | 4 | **62** | **B** | RFI for a CEP-backed API only; exclude Jadcherla from proposed chain absent verified enforcement closure and peptide-specific qualification. |

| M07 | **PeptiStar Inc.** | Japan | Non-sterile API/DS only | 11 | 17 | 10 | 5 | 7 | 6 | **56** | **B** | Confidential RFI and audit candidate only after Japanese licence/GMP and customer-authorized dossier evidence. |

| M08 | **Ajinomoto Bio-Pharma Services (Japan)** | Japan | API/DS platform; no current in-group sterile DP | 12 | 18 | 8 | 5 | 7 | 5 | **55** | **B** | Technology-fit RFI only; require precise legal/site flow and independently verified GMP evidence before audit. |

| M09 | **HLB PEP Co., Ltd.** | South Korea | API/DS only | 16 | 15 | 8 | 10 | 6 | 3 | **58** | **B** | RFI for a defined API only; APQR retrospective impact assessment and MFDS closure are hard gates. |

| M10 | **ScinoPharm Taiwan, Ltd.** | Taiwan | API/DS plus TFDA-evidenced sterile DP and packaging | 23 | 18 | 11 | 14 | 7 | 6 | **79** | **A** | Tier A for RFI priority only, conditional on historical FDA package, site genealogy, sterile assurance, supplier map and SAHPRA pathway. |


**Score interpretation.** ScinoPharm is Tier A only for first-priority RFI. Every other manufacturer remains Tier B and none is purchase-approved. Scores would be reduced if complete inspection records, licences, product-specific scope, raw data, subcontractors or material genealogy are withheld or contradict the public record.

## 5. Concise manufacturer profiles and evidenced markets

### M01 — WuXi TIDES / WuXi STA (WuXi AppTec) (China) — 72/100, Tier B

**Site and supply boundary.** Changzhou and Taixing, Jiangsu (peptide API); Wuxi City, Jiangsu (sterile drug product). The supportable public scope is **API/DS; separate sterile DP/fill-finish**. [^WUXI-INSPECT][^WUXI-FDA]


**Regulatory and market evidence.** Strong scale and inspection signals; incomplete public EIR/483/certificate package. **Evidenced or bounded markets:** United States (company-reported 2025 FDA surveillance/PAI); EU, Japan, South Korea, China and Brazil signals require primary-record confirmation; South Africa: Unknown


**Adverse history and uncertainty.** Incomplete 2023 Wuxi 483 artifact; new Taixing ramp; June 2026 US Section 1260H designation remains under enjoined, pending litigation and is geopolitical, not a GMP finding.


**Resilience and decision.** Jiangsu concentration, opaque critical-material origins/dual sourcing, special-building-block sole-source example, no qualified South Africa lane or mapped subcontractors. **Screening decision:** Enhanced RFI and separate API-versus-fill-finish audits; no award.

### M02 — Sinopep-Allsino Biopharmaceutical Co., Ltd. (China) — 62/100, Tier B

**Site and supply boundary.** Lianyungang, Jiangsu (principal peptide API and claimed finished dose). The supportable public scope is **API/DS strongest; sterile DP conditional; no device qualification**. [^SINO-CSRC]


**Regulatory and market evidence.** Multiple FDA inspection claims and peptide DMFs, but recent primary EIR/classification unavailable. **Evidenced or bounded markets:** China; US FDA inspection/DMF evidence; issuer-reported sales to India/Canada and region-level Europe; PMDA list entry; MFDS/ANVISA claims unverified; South Africa: Unknown


**Adverse history and uncertainty.** CSRC Decision [2025] 148 found materially false financial disclosure and imposed RMB47.4 million company fine; governance/data-reliability red flag, not a GMP finding.


**Resilience and decision.** Single principal site; opaque raw-material, solvent, container/device and subcontractor network; no South Africa lane. **Screening decision:** Enhanced RFI focused on API; governance remediation and raw-data audit are gates.

### M03 — Hybio Pharmaceutical Co., Ltd. (China) — 73/100, Tier B

**Site and supply boundary.** Wuhan (peptide API); Pingshan, Shenzhen (sterile DP/prefilled pen). The supportable public scope is **API/DS plus evidenced sterile/prefilled DP chain**. [^HYBIO-LABEL][^HYBIO-FDA]


**Regulatory and market evidence.** Best product-linked evidence after ScinoPharm, including US approved product and regulator-linked Wuhan evidence; several current certificates remain unverified. **Evidenced or bounded markets:** US (FDA-approved liraglutide ANDA chain); China; EDQM/Europe API signal; Brazil; issuer-reported Chile, Pakistan, Indonesia, Thailand and Vietnam; South Africa: Unknown


**Adverse history and uncertainty.** 2019 somatostatin assay failure and disclosure delay; Spanish atosiban authorization revoked in 2024; unresolved 2025 customs penalty reference; device chain opaque.


**Resilience and decision.** Wuhan API and Pingshan sterile single-site dependencies; unknown material origins/device suppliers; GLP-1 cold chain and product-specific import status require proof. **Screening decision:** Priority enhanced RFI; audit API and sterile/device chain separately. Tier B because adverse-history closure and current certificates are unresolved.

### M04 — CPC Scientific / Medtide (Hangzhou) (China) — 63/100, Tier B

**Site and supply boundary.** Qiantang, Hangzhou (commercial peptide API); Rocklin alternate not yet evidenced operational/approved. The supportable public scope is **API/DS only on public evidence**. [^CPC-483]


**Regulatory and market evidence.** FDA FEI and 2024 VAI/483; 2026 PLI generated another 483; product-linked Hepcludex supplier claim. **Evidenced or bounded markets:** US; China; company-reported Germany/EU, Australia and South Korea; South Africa: Unknown


**Adverse history and uncertainty.** 2012 FDA registration/listing warning letter; 2024 validation/equipment-qualification observations; 2026 483 contents/classification unavailable.


**Resilience and decision.** High utilization and one evidenced commercial source; PRC upstream concentration; no qualified South Africa lane; external sterile chain required. **Screening decision:** RFI only; full 2024/2026 FDA packages and remediation effectiveness are hard gates.

### M05 — Piramal Pharma Solutions, Turbhe (India) — 70/100, Tier B

**Site and supply boundary.** Turbhe, Navi Mumbai (peptide API); Lexington, US is separate sterile DP site. The supportable public scope is **API/DS; Turbhe is not evidenced as sterile DP**. [^PIR-WHO-OXY][^PIR-WHO-CAR][^PIR-483]


**Regulatory and market evidence.** High-value WHO product/site evidence, offset by February 2025 FDA 483 and VAI. **Evidenced or bounded markets:** US inspection/supply evidence; WHO-prequalified oxytocin and carbetocin API; EDQM-linked oxytocin evidence; South Africa: no Turbhe-specific linkage found


**Adverse history and uncertainty.** Six FDA observations included quality-unit, repeated deviation, complaint, cleaning, batch-record and temperature-control deficiencies.


**Resilience and decision.** Single peptide API site; FDA-documented cold-chain KSM failure; shared-equipment cleaning risk; external FPP and container chain. **Screening decision:** Priority RFI for WHO-backed products; require FDA CAPA effectiveness and lane challenge before audit closure.

### M06 — Shilpa Pharma Lifesciences / Shilpa Medicare (India) — 62/100, Tier B

**Site and supply boundary.** Raichur Units I/II (API); Jadcherla Unit IV (separate finished dose). The supportable public scope is **API/DS; sterile DP not peptide-qualified and enforcement-affected**. [^SHILPA-WL]


**Regulatory and market evidence.** Peptide CEP evidence and multiple regulatory signals, but exact site/equipment linkage remains unclear. **Evidenced or bounded markets:** EDQM CEP signals for desmopressin/octreotide; US inspection/DMF claim; Japan and Brazil inspection signals; South Africa: Unknown


**Adverse history and uncertainty.** Raichur Unit I 2025 VAI; Jadcherla finished-dose 2020 FDA warning letter and unresolved public Import Alert 66-40 status.


**Resilience and decision.** Raichur concentration and uncertain alternate trains; imported raw materials; purification/lyophilization bottlenecks; opaque subcontracting. **Screening decision:** RFI for a CEP-backed API only; exclude Jadcherla from proposed chain absent verified enforcement closure and peptide-specific qualification.

### M07 — PeptiStar Inc. (Japan) — 56/100, Tier B

**Site and supply boundary.** Settsu, Osaka single campus (R&D and Manufacturing Buildings 1/2). The supportable public scope is **Non-sterile API/DS only**. [^PEPTISTAR]


**Regulatory and market evidence.** Legal entity and purpose-built platform evidenced, but no public regulator inspection, certificate, dossier or approved-product linkage. **Evidenced or bounded markets:** No specific regulated therapeutic country/site/product linkage publicly evidenced; South Africa: Unknown


**Adverse history and uncertainty.** No public enforcement located, but absence is not proof of a clean history; ownership/control and commercial batch history are incomplete.


**Resilience and decision.** Single-campus natural-hazard/utility exposure; proprietary technology dependencies; unknown critical-material origins; external sterile chain required. **Screening decision:** Confidential RFI and audit candidate only after Japanese licence/GMP and customer-authorized dossier evidence.

### M08 — Ajinomoto Bio-Pharma Services (Japan) (Japan) — 55/100, Tier B

**Site and supply boundary.** Tokai, Mie (candidate AJIPHASE); Osaka/GeneDesign; Kawasaki is separate API/R&D context. The supportable public scope is **API/DS platform; no current in-group sterile DP**. [^AJI-FDA]


**Regulatory and market evidence.** Strong technology/company platform but exact legal site, licence, inspection and peptide-product linkage are unresolved. **Evidenced or bounded markets:** No named therapeutic-peptide market linked to Tokai/Osaka; US AJIPHASE approval disclosure appears oligonucleotide; South Africa: Unknown


**Adverse history and uncertainty.** Kawasaki 2025 FDA 483/VAI signal for investigations, document control and material compatibility; not automatically attributable to Tokai/Osaka.


**Resilience and decision.** Tokai concentration; licensed/proprietary technology; CORYNEX may depend on Olon; divested sterile site means third-party DP chain. **Screening decision:** Technology-fit RFI only; require precise legal/site flow and independently verified GMP evidence before audit.

### M09 — HLB PEP Co., Ltd. (South Korea) — 58/100, Tier B

**Site and supply boundary.** Jangseong Plant 1 and Osong Plant 2 (peptide API); Gwangju is non-GMP/pilot. The supportable public scope is **API/DS only**. [^HLB-DMF]


**Regulatory and market evidence.** Current issuer-reported MFDS re-certifications and active DMFs; no public FDA inspection classification or approved-product linkage. **Evidenced or bounded markets:** South Korea; active US Type II DMFs; reported Japan recognition and historical India export authorization; South Africa: Unknown


**Adverse history and uncertainty.** Confirmed 2025 one-month MFDS suspension for missing 2022/2023 APQRs on two Jangseong products; closure/effectiveness package unavailable.


**Resilience and decision.** Product-level site mapping and alternate-site status unknown; modest/reconciling capacity claims; raw-material origins and subcontractors opaque. **Screening decision:** RFI for a defined API only; APQR retrospective impact assessment and MFDS closure are hard gates.

### M10 — ScinoPharm Taiwan, Ltd. (Taiwan) — 79/100, Tier A

**Site and supply boundary.** Tainan (peptide API, sterile fill-finish, packaging and cold-chain GDP); Changshu, China is separate. The supportable public scope is **API/DS plus TFDA-evidenced sterile DP and packaging**. [^SCINO-TFDA-API][^SCINO-TFDA-STERILE][^SCINO-LABEL]


**Regulatory and market evidence.** Strongest public site/product/sterile-scope combination; current TFDA API, sterile and GDP evidence plus US marketed-product linkage. **Evidenced or bounded markets:** United States (ANDA-linked glatiramer PFS); Taiwan; historical/current signals for Europe, Japan and Brazil; South Africa: Unknown


**Adverse history and uncertainty.** Historical 2012 VAI reported secondarily and 2015 FDA 483/EIR indexed; current primary FDA classifications/CAPA not reviewed.


**Resilience and decision.** Tainan concentration; semaglutide side-chain route may add Changshu/cross-strait exposure; unknown component suppliers and no South Africa lane. **Screening decision:** Tier A for RFI priority only, conditional on historical FDA package, site genealogy, sterile assurance, supplier map and SAHPRA pathway.

## 6. Regulatory and adverse-history screen

FDA defines **NAI** as no objectionable conditions or practices, **VAI** as objectionable conditions found but no administrative or regulatory action prepared or recommended, and **OAI** as regulatory or administrative action recommended. A VAI is therefore not a clean bill of health. FDA also cautions that its public inspection-classification database is not comprehensive and excludes some inspection types, including PAIs; a missing public classification is not evidence that an inspection did not occur or was acceptable.[^FDA-CLASS][^FDA-ICD]

The following events are diligence gates rather than automatic cross-company conclusions. Site and activity boundaries matter: a finished-dose warning letter cannot automatically be assigned to an affiliated API site, but it is relevant to group quality governance and becomes directly material if that finished-dose site enters the proposed chain.


| Entity/site | Public event | Correct interpretation | Gate before progression |
|---|---|---|---|
| WuXi/Wuxi, Changzhou, Taixing | Incomplete Wuxi 2023 FDA artifact; company-reported 2025 inspections; US Section 1260H litigation | Inspection and geopolitical issues are distinct; designation is not a GMP finding. | Complete EIRs/classifications/483 responses; legal/geopolitical continuity plan. |
| Sinopep-Allsino | CSRC 2025 false-disclosure decision | Governance and data-reliability concern, not medicinal GMP finding. | Board remediation, audit-committee evidence, DI-focused audit and record reconciliation. |
| Hybio | 2019 failed somatostatin assay batch and delayed disclosure | Product-quality and governance event; current impact cannot be inferred. | Original OOS, distribution/recall reconciliation, regulator closure and CAPA effectiveness. |
| CPC Qiantang | 2012 warning letter; 2024 VAI/483; 2026 483 | Recent recurring validation/qualification scrutiny is material. | Complete responses/EIRs, PPQ/CPV, equipment qualification and recurrence analysis. |
| Piramal Turbhe | 2025 six-observation 483 and VAI | Objectionable API-system conditions, including cold-chain and cleaning controls. | Evidence-based CAPA effectiveness and independent verification. |
| Shilpa | Raichur Unit I VAI; Jadcherla warning letter/import-alert history | Different sites; Jadcherla history directly gates any DP proposal. | Unit I inspection package; verified Jadcherla closure/removal before any DP use. |
| PeptiStar | No public regulator outcome found | Unknown, not clean. | Japanese licence, inspection and confidential customer/dossier evidence. |
| Ajinomoto | Kawasaki 2025 483/VAI signal | Not automatically Tokai/Osaka peptide-site finding, but governance signal. | Exact site flow plus cross-site CAPA applicability assessment. |
| HLB PEP Jangseong | 2025 one-month MFDS suspension for missing APQRs | Confirmed PQS failure affecting two APIs. | Retrospective APQR/product-impact review, closure and effectiveness evidence. |
| ScinoPharm | Historical 2012 VAI report and indexed 2015 483/EIR | Strong current public profile does not erase historical records. | Primary FDA records and CAPA closure; reconcile current scope. |


## 7. Independent laboratory comparison

Laboratory scores are an adapted triage index using the same 100-point philosophy: exact-site regulatory/accreditation evidence, peptide method capability, data integrity/custody, market support, resilience/subcontractor transparency and adverse-history response. They do not authorize release testing. Every method must be qualified for the exact matrix, specification and physical site.

| ID | Laboratory | Site | Score | Tier | Verified evidence boundary | Peptide-relevant role |

|---|---|---|---:|---|---|---|

| L01 | **SGS Shanghai Health Science Laboratory** | Yishan Road, Shanghai | **66** | **B** | CMA certificate includes site through 2029; claimed ISO/IEC 17025/CNAS scope annex not obtained; company reports 2024 FDA inspection with no 483, but official EIR/classification unavailable. | Specialist/conditional RFI; not sole release laboratory. |

| L02 | **Eurofins Analytical Science Laboratories, Kyoto and Kobe** | Kyoto and Kobe, Japan | **64** | **B** | PMDA 2024 Kyoto compliant result for undisclosed application scope; Kyoto FDA 2024 Form 483 unresolved; no site ISO 17025 scope verified; Kobe authority unknown. | Specialist/conditional; site- and method-specific audit required. |

| L03 | **Vimta Labs Limited, Life Sciences Facility** | Genome Valley, Hyderabad | **70** | **B** | Current NABL ISO/IEC 17025 certificate through 2028 but annex absent; current WHO-prequalified QCL listing; exact-site FDA 2023 VAI; veterinary GMP stability scope through 2027. | Priority laboratory RFI; blind split-sample qualification before use. |

| L04 | **Intertek Pharmaceutical Services India, Mumbai** | Tex Centre, Andheri East, Mumbai | **46** | **C** | Current IAS ISO 17025 scope is environmental, not pharmaceutical; prior NABL scope expired and was non-pharma; claimed MH-FDA approval lacks primary certificate; no FDA site record verified. | Do not use as sole release lab; RFI only for bounded specialist research pending primary licences/scopes. |


**Laboratory decisions.** Vimta should receive the first laboratory RFI; SGS and Eurofins should receive method-specific RFIs in parallel. Intertek Mumbai is not suitable as the sole independent release laboratory on current public evidence because the verified accreditation scope is non-pharmaceutical. For all four, corporate-network capabilities must not be imputed to the named site, and no work may move between buildings, cities, affiliates or overseas laboratories without prior written approval and requalification.

## 8. Quality-testing specification

The final specification must be derived from the registered dossier, pharmacopoeial commitments, process knowledge, dosage form and stability programme. The following is a **qualification framework**, not a universal release specification and not numerical acceptance criteria. Methods should be stability-indicating, validated or verified for the exact matrix, and transferred under an approved protocol.


| Control domain | API/drug-substance expectation | Additional sterile drug-product expectation | Evidence required |
|---|---|---|---|
| Identity and structure | Intact mass, sequence/peptide mapping, amino-acid composition where justified, stereochemical/epimer controls, disulfide/connectivity and modification identity | Confirmation after formulation/fill; device/container compatibility where relevant | Method validation/verification, sequence coverage, orthogonal identity and reference-standard qualification |
| Assay/content | Corrected peptide content and/or assay with explicit water, counter-ion and potency basis | Delivered concentration, fill volume and dose-uniformity controls as registered | Traceable calculations, correction factors, system suitability and uncertainty/range justification |
| Purity/related substances | RP-HPLC/UPLC plus orthogonal LC-MS strategy for deletions, insertions, truncations, epimers, oxidation, deamidation/aspartimide, aggregation and process impurities | Degradation products through shelf life and in-use period | Impurity fate/purge, response factors, LOQ, co-elution controls, forced degradation and mass balance |
| Residual/process impurities | Residual solvents, TFA/other counter-ion, protecting groups, scavengers, coupling reagents, resin/linker leachables, elemental/genotoxic/nitrosamine risk as applicable | Preservatives/excipients and process residuals | ICH risk assessments, validated HS-GC/IC/ICP/LC-MS methods and supplier-origin inputs |
| Physical attributes | Appearance, solubility, water, counter-ion, particle size/polymorph where relevant, bulk density and packaging | pH, osmolality, visible/subvisible particles, appearance, reconstitution time and extractable volume where relevant | Registered methods, development rationale, trend limits and stability data |
| Microbiological | Bioburden and endotoxin where process/product requires | Sterility, endotoxin, microbial controls, environmental/utility linkage | Method suitability, interference/recovery, media/isolator qualification and excursion controls |
| Sterility assurance | Not applicable to non-sterile API beyond appropriate microbial controls | CCS, APS/media fills, intervention qualification, EM trends, PUPSIT rationale where applicable, sterilization/depyrogenation, CCIT | Latest protocols/reports, worst-case matrix, deviations and ongoing verification |
| Container/device | Bulk container compatibility, closure integrity where required, shipping hold times | CCI through shelf life, E&L, silicone/tungsten, break-loose/glide force, dose accuracy, assembly and serialization | Supplier qualification, component CoAs, design/validation files and registered change controls |
| Stability/GDP | ICH long-term/accelerated/stress, retest, bulk holds, freeze/thaw and shipping excursions | Shelf life, in-use, light/freeze/heat protection and device functionality | Three representative batches, chamber maps, OOT rules, lane qualification and excursion decision tree |
| Data integrity | Complete contemporaneous original data; controlled processing and review | Same, plus EM, APS, CCIT and device electronic records | Native files, metadata, audit trails, integration history, roles, backup/restore and periodic review |


## 9. Supply-chain dependency map

The common critical path is: **protected/nonnatural amino acids and specialty building blocks → resin/linker or soluble anchor → coupling/deprotection reagents and solvents → synthesis train → cleavage/deprotection → preparative chromatography/TFF/precipitation → isolation/bulk lyophilization → API QC/release → temperature-controlled storage/export → sterile formulation/fill-finish where applicable → container/device assembly → secondary packaging/serialization → import and authorized South African release**.

Public evidence is weakest upstream and at handoffs. Supplier names, manufacturing countries, dual-source status, safety stocks and change controls for protected amino acids, resins, fatty-acid side chains, linkers, coupling reagents, acetonitrile, DMF/NMP/DCM, TFA, scavengers and chromatography media are generally Unknown. Purification column capacity and bulk lyophilizer occupancy are likely practical bottlenecks even where synthesis reactor volume is large. Device components, elastomers, needles, sterilization, external microbiology, warehousing, QP/release and freight subcontractors are usually not mapped. South African lane qualification and customs-delay simulations were not publicly evidenced for any manufacturer.


| Dependency | Failure mode | Required control | Commercial remedy |
|---|---|---|---|
| Protected/special amino acid or conjugation building block | Sole source, chiral/impurity drift, export restriction | Manufacturer and country genealogy; impurity profile; second-source comparability; safety stock | Dual-source milestone; notification and approval rights; inventory floor |
| Resin/linker/anchor | Capacity shortage, leachables, yield change | Approved maker/grade; leachable assessment; lot qualification; alternate support study | Reserved capacity and transfer package |
| Solvents/reagents | Shortage, recovered-solvent contamination, environmental outage | Source map, recovery controls, testing, utility/environmental permits and continuity plan | Minimum stocks and qualified alternates |
| Purification/lyophilization | Campaign bottleneck, carryover, long cycle | Demonstrated saleable throughput, column lifecycle, cleaning validation, spare strategy | Capacity reservation and alternate train/site |
| Single API/sterile site | Natural hazard, utility loss, inspection interruption | BCP tests, backup utilities, alternate dossier/site plan, recovery time objective | Technology-transfer rights and step-in/termination assistance |
| External test/sterilization/release | Undisclosed subcontracting, data loss | Prior approval, audit rights, complete raw data, no further subcontracting | Named schedule to quality agreement |
| Cold chain/export | Excursion, customs delay, logger failure | Lane qualification to South Africa, seasonal challenge, customs hold simulation, excursion SOP | Validated packaging, backup carrier and inventory buffer |
| Geopolitical/currency/cyber | Sanctions, payment/insurance failure, data access limits | Screening, legal monitoring, cyber/backup audit, currency and insurance plan | Alternate geography and exit/transfer clauses |


## 10. South African/SAHPRA and import fit

Public evidence did not establish a SAHPRA registration, site recognition or dossier linkage for any proposed chain. The South African applicant/importer must determine the applicable product classification and legal pathway with SAHPRA, maintain the authorized manufacturer and testing/release chain in the dossier, and hold all licences required for the activities it performs. SAHPRA guidance on manufacturing-licence applications and Site Master Files reinforces that regulated activities and sites must be described and licensed; a foreign certificate or independent test does not replace those obligations.[^SAHPRA-LIC][^SAHPRA-SMF]

For diligence purposes, **South Africa fit is Unknown until documented**. The RFI must identify the local applicant/registration holder, importer, wholesaler/distributor, pharmacovigilance owner, responsible pharmacist/authorized release role where applicable, tariff/customs handling, port/airport entry, bonded or controlled-temperature storage, secondary packaging/serialization responsibilities, complaints/recall chain and exact SAHPRA dossier modules/letters of access. The sponsor should obtain South African regulatory advice before contracting and should not ship commercial or registration material until approvals, licences, permits and dossier consistency are confirmed.

Independent retesting may supplement assurance but cannot “test into compliance,” cure an unlicensed site, substitute for validated manufacture, overwrite an OOS, or alter a registered specification without authorization. Any South African confirmatory or lot-release testing required by the approved dossier must be assigned to a qualified, authorized laboratory under the registered arrangement.

## 11. RFI approach and product/site/batch-specific request list

Issue a controlled, numbered RFI under confidentiality. Responses should identify the document owner, effective date, language, translator and redaction rationale; unsigned sales presentations should not satisfy quality questions. Require direct regulator-verifiable copies or regulator portal references where possible. Every answer must state **Unknown/Not applicable** rather than remain blank.


| RFI package | Mandatory documents and data |
|---|---|
| Corporate/legal | Contracting and manufacturing legal entities; ownership/UBO; registrations; all site addresses; organization chart; financial/insurance continuity; sanctions/export-control declaration |
| Product/site genealogy | Proposed product and salt/counter-ion; therapeutic GMP status; every synthesis, purification, isolation, milling, test, release, storage, fill, sterilization, device, packaging and export site; building/line/equipment IDs; research-to-GMP transfer boundary |
| Licences/regulatory | Current local manufacturing licences and annexes; GMP certificates; FEI and inspection history; last three inspections, 483s/observations, responses, EIRs/classifications and commitments; warning/import-alert/non-compliance/recall history; CEP/DMF/ASMF and LoA status |
| Process/validation | Route and flow chart; critical materials and CPP/CQAs; three PPQ/commercial-scale batch packages; CPV/APR/PQR; yields and impurity trends; holds; reprocessing/rework; cleaning validation/HBEL; campaign and cross-contamination strategy |
| Analytical/DI | Registered specification; methods and validation/transfer; reference standards; raw chromatograms/spectra; audit trails and integration history; OOS/OOT/deviation/CAPA and invalidation metrics for 36 months; CSV, access roles, backup/restore and DI audits |
| Stability/transport | Retest/shelf-life protocol and data; forced degradation; in-use and freeze/thaw where applicable; bulk/container compatibility; shipping study; South Africa lane, seasonal challenge, customs-delay simulation, logger and excursion governance |
| Sterile/device | CCS; APS/media fills; EM and intervention trends; sterilization/depyrogenation; filter validation/PUPSIT rationale; CCI; particles; E&L; component suppliers; device assembly, dose accuracy, human factors, packaging and serialization |
| Supply network | Approved manufacturer and country for each critical raw material; dual-source status; safety stock; supplier audits/quality agreements; solvent recovery; utilities/environmental permits; all subcontractors and further-subcontract controls |
| Performance | Three years of batches, rejects, complaints, recalls, shortages, OTIF, deviations, OOS/OOT, CAPA ageing/recurrence, change controls, staff turnover, capacity utilization and business-continuity exercises |
| South Africa | CTD/ASMF/CEP support; LoA; applicant/importer proposal; SAHPRA history; local testing/release; GDP distribution; PV, complaint and recall interface; change-notification commitments |


## 12. Ninety-day qualification workflow and audit plan


| Timing | Decision activity | Deliverable and gate |
|---|---|---|
| Days 0–10 | Freeze product target profile, dosage form, annual demand, registered-market strategy and non-negotiable evidence list; issue NDA/RFI | Approved user requirement and one exact proposed chain per supplier |
| Days 11–25 | Verify legal entities, licences, regulator records, dossier references, sanctions/export constraints and adverse-history packages | Documentary completeness score; reject evasive or mismatched proposals |
| Days 26–40 | Technical review of route, scale, PPQ/CPV, impurity strategy, analytical/stability data, cleaning and sterile/device evidence | Product/site technical risk assessment and audit agenda |
| Days 41–55 | Supply-chain and commercial review: source genealogy, capacity, subcontractors, BCP, cold chain, South Africa lane and quality-agreement redlines | Approved dependency map, capacity reservation terms and preliminary SAHPRA gap assessment |
| Days 56–70 | Risk-based on-site audit of each proposed API and DP site; remote document room only as contingency, not default for high-risk gaps | Critical/major/other findings; raw-data and facility observations; preliminary disposition |
| Days 61–78 | Laboratory audit and blind split-sample method exercise in parallel | Method-by-method comparability, custody and raw-data assessment |
| Days 71–85 | Supplier CAPA response, evidence review and quality/technical agreement closure | Acceptable root cause, actions, owners, dates and effectiveness plan; no critical open finding |
| Days 86–90 | Cross-functional quality, regulatory, supply, legal and commercial board | Conditional shortlist, hold, or no-go; approved next milestones and expiry/reassessment date |


**Manufacturer audit plan.** Begin with opening/legal-scope confirmation and trace one representative commercial batch from material receipt to distribution. Inspect warehouses and sampling, synthesis and solvent systems, purification and column lifecycle, isolation/lyophilization, cleaning status, utilities, QC sample login, reference standards, chromatography/mass-spectrometry data systems, retains, stability chambers, deviations and change controls. Select adverse-history cases and recurring deviations rather than only supplier-chosen examples. Review native electronic records, metadata, deleted/aborted sequences, reintegrations, audit trails, user privileges and backup restoration. For sterile sites, observe material/personnel flows, isolators/RABS, filling interventions, EM, APS, sterilization/depyrogenation, filters, CCI, particles and component controls. Close by agreeing finding classification, evidence, immediate containment and CAPA dates.

**Audit sampling.** Select at least one recent release batch, one deviation/OOS batch, one reprocessed/reworked or low-yield batch if any, one stability OOT or complaint case, one cleaning-validation run and one supplier change. For a sterile chain, add one failed/aborted APS if any, one EM action-level event and one CCI or particulate investigation. Sampling is risk-driven and may expand if inconsistencies appear.

## 13. Red-flag and no-go criteria

A **no-go or immediate hold** is required for fabricated, altered, backdated or selectively deleted data; refusal of native data or audit trails; an unlicensed activity/site; undisclosed manufacturing or testing subcontracting; material mismatch between contract, licence, dossier and actual site; ongoing OAI, import ban or regulator restriction applicable to the proposed chain without accepted resolution; inability to identify critical-material manufacturers/countries; commercial therapeutic use of research/non-GMP material; sterility-assurance failure without validated containment and closure; release after unexplained OOS/retesting into compliance; critical cross-contamination/cleaning risk; inability to support SAHPRA dossier and inspection needs; sanctions/export restrictions that make lawful supply infeasible; or refusal to sign quality/change-control/audit/recall obligations.

A **conditional hold** applies to incomplete EIRs, current certificates, product-specific method validation, three-batch PPQ/CPV, APQR/PQR, CAPA effectiveness, cold-chain lane, CCI/E&L/device documentation, dual sourcing or BCP evidence. Conditional items require owners, evidence and deadlines and do not permit purchase or release until the decision board closes them.

## 14. Laboratory qualification protocol

Laboratory qualification begins with the exact legal entity, address, controlled rooms/floors and regulatory/accreditation regime for each method. Obtain the current certificate **and full scope annex**, inspection reports and CAPA, organization and conflicts declaration, instrument inventory, analyst qualifications, validation/transfer SOPs, OOS/OOT/CAPA procedures, raw-data architecture, reference-standard lifecycle, chamber maps, sample/retain procedures, subcontractors and disaster recovery. Confirm whether each report is issued under ISO/IEC 17025 scope, GMP licence, another regulated scope, or unaccredited research service.

Audit each proposed method against the registered specification and validation status. Verify sequence coverage and orthogonality for LC-MS identity; impurity resolution, response factors, LOQ and forced degradation for HPLC/UPLC; matrix recovery for elemental and residual-solvent methods; peptide content corrections; microbial/sterility/endotoxin method suitability; CCI detection limit and deterministic method where appropriate; E&L study design and toxicological responsibility; and stability chamber mapping, alarms and backup. Require controlled reference-standard potency/water/counter-ion assignment and reconciliation.

The quality agreement must prohibit unapproved subcontracting and testing into compliance; preserve all original, repeat and invalidated data; provide sponsor and regulator access to native files, metadata, audit trails, integration history and calculations; define OOS/OOT notification before retesting; fix retain quantities/conditions/duration; control method/specification/software/instrument changes; and require data retention, cybersecurity, backup/restore and business-continuity testing.

## 15. Split-sample and chain-of-custody design

Use at least three representative lots, including a lot near an impurity or assay trend boundary where lawfully available. Sampling must be performed by trained personnel under an approved statistically defensible plan from identified containers, not from supplier-prepared convenience aliquots. Record bulk/container IDs, sampler, date/time, room conditions, tools, composite rationale, sample weights, seals and photographs. Create three uniquely coded aliquot sets: manufacturer laboratory, candidate independent laboratory and sponsor/qualified South African retain. Blind the independent laboratory to the manufacturer result until its report is locked.

Use tamper-evident serialized seals, temperature-qualified packaging, calibrated loggers for temperature-sensitive material, documented courier handoffs and receipt checks. The laboratory logs condition, seal, weight, temperature data, discrepancies, storage location and every aliquot/transfer in LIMS. Deviations stop testing pending sponsor disposition. No sample may move to another site or affiliate without written approval.

Predefine comparability rules in the protocol based on validated-method precision, inter-laboratory bias and specification—not improvised percent differences. Investigate discordance jointly using complete raw data, system suitability, standards, columns, integrations, analyst steps and sample homogeneity. Do not average away an OOS. Retest or resample only after a documented scientifically assignable cause and sponsor approval. The protocol ends with method/site approval, restrictions, CAPA or rejection and is repeated after material method, instrument, site or specification changes.

## 16. Next decisions

1. **Approve RFI issuance, not purchase approval.** Send first-wave manufacturer RFIs to ScinoPharm, Hybio, Piramal and WuXi, plus one molecule-matched API comparator. Keep all decisions product/site-specific.
2. **Treat ScinoPharm as conditional Tier A.** Verify historical FDA records, current site chain, sterile assurance, component suppliers and South African regulatory support before retaining that status.
3. **Prioritize product-linked routes.** For oxytocin/carbetocin, Piramal’s WHO evidence is decision-relevant but its 2025 FDA remediation is gating. For a PFS/pen project, verify Hybio or ScinoPharm’s complete API-to-device chain rather than accepting corporate integration claims.
4. **Begin independent-laboratory RFIs with Vimta, SGS and Eurofins.** Design one blind split-sample exercise after documentary screening. Hold Intertek Mumbai to bounded specialist work unless primary pharmaceutical scope is produced.
5. **Commission South African regulatory gap assessment.** Fix applicant/importer/licence, dossier/LoA, local testing/release, GDP and PV/recall responsibilities before any registration or commercial shipment.
6. **Negotiate continuity rights early.** Require complete source/subcontract maps, change approval, capacity reservation, inventory floors, South Africa lane validation, alternate-site/technology-transfer milestones, audit rights and exit assistance.
7. **Re-score at day 85.** Use verified confidential evidence and audit outcomes; do not carry forward public-evidence points when the underlying scope is contradicted or withheld.

## 17. Limitations

This report is based on information available through the stated decision date. Public inspection databases can be incomplete; company statements may omit scope, observations or later events; certificates can be product-, building-, activity- and time-specific; names and addresses can change; and confidential customers, dossier links, quality metrics and subcontractors are generally unavailable. Bounded negative searches do not prove absence of enforcement, recalls or defects. A DMF filing is not approval; a CEP supports defined substance controls but does not approve a finished product; a marketed product does not automatically qualify every site or capability of a group; and audited financial statements are not GMP evidence.

Scores are judgmental but transparent. They are **public-evidence screening scores only** and never final approval. No testing was performed, no site was audited, no confidential regulatory correspondence was reviewed and no SAHPRA determination was made. The source register contains every URL extracted from the discovery document and fourteen dossiers; links may later move or require archived retrieval. The dossiers remain the controlling detailed narratives where this report summarizes complex findings.

## 18. Complete reference list

### 18.1 Core references cited in this report

[^SAHPRA-LIC]: https://www.sahpra.org.za/wp-content/uploads/2022/06/SAHPGL-LIC-01-Guide-On-How-to-Apply-for-A-Licence-To-Manufacture_DN.pdf

[^SAHPRA-SMF]: https://www.sahpra.org.za/wp-content/uploads/2022/09/SAHPGL-INSP-04_v5Guidelines-for-Preparation-of-Site-Master-File.pdf

[^FDA-CLASS]: https://www.fda.gov/inspections-compliance-enforcement-and-criminal-investigations/inspection-basics/inspection-classifications

[^FDA-ICD]: https://www.fda.gov/inspections-compliance-enforcement-and-criminal-investigations/inspection-classification-database

[^WUXI-INSPECT]: https://sta.wuxiapptec.com/wuxi-apptecs-changzhou-and-taixing-api-sites-successfully-pass-fda-inspections/

[^WUXI-FDA]: https://www.fda.gov/drugs/guidance-compliance-regulatory-information/wuxi-sta-pharmaceutical-co-ltd-3032023

[^SINO-CSRC]: https://www.csrc.gov.cn/csrc/c101928/c7603410/content.shtml

[^HYBIO-LABEL]: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=2100ec49-57b2-4330-ab5f-057ce9b7e4d0

[^HYBIO-FDA]: https://www.fda.gov/news-events/press-announcements/fda-approves-first-generic-once-daily-glp-1-injection-lower-blood-sugar-patients-type-2-diabetes

[^CPC-483]: https://static.propublica.org/fda-inspection-documents/483s/2024-10801%2F240010163_enc2_320.pdf

[^PIR-WHO-OXY]: https://extranet.who.int/prequal/medicines/active-pharmaceutical-ingredient/whoapi-361-oxytocin

[^PIR-WHO-CAR]: https://extranet.who.int/prequal/medicines/active-pharmaceutical-ingredient/whoapi-423-carbetocin

[^PIR-483]: https://www.fda.gov/media/185578/download

[^SHILPA-WL]: https://www.fda.gov/inspections-compliance-enforcement-and-criminal-investigations/warning-letters/shilpa-medicare-limited-607877-10092020

[^PEPTISTAR]: https://peptistar.com/en/facility/

[^AJI-FDA]: https://www.fda.gov/drugs/cder-foia-electronic-reading-room/ajinomoto-company-inc-02212025

[^HLB-DMF]: https://www.fda.gov/drugs/drug-master-files-dmfs/list-drug-master-files-dmfs

[^SCINO-TFDA-API]: https://www.fda.gov.tw/TC/siteListContent.aspx?sid=2067&id=3723

[^SCINO-TFDA-STERILE]: https://www.fda.gov.tw/TC/siteListContent.aspx?sid=2067&id=39453

[^SCINO-LABEL]: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=707a64ef-964e-44a3-8a0f-fcc2eb5b1af2

[^SGS-FDA]: https://www.sgs.com/en-us/news/2024/10/shanghai-health-science-lab-passes-us-fda-inspection

[^EURO-PMDA]: https://www.pmda.go.jp/files/000277257.xlsx

[^EURO-483]: https://www.fda.gov/media/177453/download

[^VIMTA-WHO]: https://extranet.who.int/prequal/sites/default/files/whopir_files/WHOPIR_VimtaLabs_18-20January2023_0.pdf

[^VIMTA-NABL]: https://vimta.com/wp-content/uploads/2026/05/Latest-NABL-Certificate-2026.pdf

[^INTERTEK-IAS]: https://www.iasonline.org/ias_certificate/tl-1217/


### 18.2 Full dossier source register

The complete reference inventory contains **301 unique URLs** and is supplied as `source_register.csv`. For auditability, the URLs are also listed below with stable register identifiers.

- **SRC-001** — Discovery; Discovery universe: https://www.fda.gov/drugs/drug-approvals-and-databases/drug-establishments-current-registration-site-decrs

- **SRC-002** — Discovery; Discovery universe: https://tides.wuxiapptec.com/

- **SRC-003** — Discovery; Discovery universe: https://tides.wuxiapptec.com/wuxi-apptecs-changzhou-and-taixing-api-sites-successfully-pass-fda-inspections/

- **SRC-004** — Discovery; Discovery universe: https://www.sinopep.com/quotation/gmp-peptides/

- **SRC-005** — Discovery; Discovery universe: https://www.fda.gov/media/190915/download

- **SRC-006** — Discovery; Discovery universe: https://www.fda.gov/media/183518/download

- **SRC-007** — Discovery; Discovery universe: https://www.hybio.com/about-us/

- **SRC-008** — Discovery; Discovery universe: https://www.fda.gov/media/148286/download

- **SRC-009** — Discovery; Discovery universe: https://cpcscientific.com/custom-peptide-synthesis/cgmp-peptide-manufacturing/

- **SRC-010** — Discovery; Discovery universe: https://www.fda.gov/media/178556/download

- **SRC-011** — Discovery; Discovery universe: https://www.fda.gov/media/181469/download

- **SRC-012** — Discovery; Discovery universe: https://www.piramalpharmasolutions.com/specialized-offerings/peptides-api

- **SRC-013** — Discovery; Discovery universe: https://shilpapharma.com/peptide-cdmo-services/

- **SRC-014** — Discovery; Discovery universe: https://peptistar.com/en/company/message/

- **SRC-015** — Discovery; Discovery universe: https://www.amed.go.jp/en/news/release_20191206.html

- **SRC-016** — Discovery; Discovery universe: https://ajibio-pharma.ajinomoto.com/

- **SRC-017** — Discovery; Discovery universe: https://hlbpep.co.kr/eng/peptides/gmp.php

- **SRC-018** — Discovery; Discovery universe: https://www.scinopharm.com/solutions/SPTCMC/

- **SRC-019** — Discovery; Discovery universe: https://www.scinopharm.com/news-detail/113/

- **SRC-020** — Discovery; Discovery universe: https://www.sgs.com/en-us/news/2024/10/shanghai-health-science-lab-passes-us-fda-inspection

- **SRC-021** — Discovery; Discovery universe: https://www.sgsgroup.com.cn/en-cn/services/pharmaceutical-microbiology-testing

- **SRC-022** — Discovery; Discovery universe: https://location.eurofins.com/en/ele/eurofins-analytical-science-laboratories-inc/

- **SRC-023** — Discovery; Discovery universe: https://www.eurofins.com/en/media-centre/press-releases/2018-05-22/

- **SRC-024** — Discovery; Discovery universe: https://vimta.com/wp-content/uploads/2026/05/Latest-NABL-Certificate-2026.pdf

- **SRC-025** — Discovery; Discovery universe: https://vimta.com/wp-content/uploads/2026/05/DCA-Licence-Renewal.pdf

- **SRC-026** — Discovery; Discovery universe: https://vimta.com/about-us/accreditations/

- **SRC-027** — Discovery; Discovery universe: https://www.intertek.com/pharmaceutical/mumbai-india/

- **SRC-028** — Discovery; Discovery universe: https://nabl-india.org/nabl/file_download1.php?filename=202404180952-TC-5663-doc.pdf

- **SRC-029** — Discovery; Discovery universe: http://www.neulandlabs.com/en/about-us/our-facilities/peptide-manufacturing-facility-hyderabad

- **SRC-030** — Discovery; Discovery universe: http://www.peptron.com/ds3_4_1.html

- **SRC-031** — Discovery; Discovery universe: https://www.fda.gov/inspections-compliance-enforcement-and-criminal-investigations/warning-letters/auriga-research-pvt-ltd-730694-08122026

- **SRC-032** — Manufacturer; 01-M01: https://www.hkexnews.hk/listedco/listconews/sehk/2026/0323/2026032300516.pdf

- **SRC-033** — Manufacturer; 01-M01: https://tides.wuxiapptec.com/services-solutions/peptide/peptide-cmc/drug-product/

- **SRC-034** — Manufacturer; 01-M01: https://sta.wuxiapptec.com/wuxi-apptecs-changzhou-and-taixing-api-sites-successfully-pass-fda-inspections/

- **SRC-035** — Manufacturer; 01-M01: https://tides.wuxiapptec.com/facility/changzhou-china/

- **SRC-036** — Manufacturer; 01-M01: https://sta.wuxiapptec.com/wuxi-sta-successfully-passes-four-pre-approval-inspections-by-south-koreas-ministry-of-food-and-drug-safety-at-three-manufacturing-sites-in-china/

- **SRC-037** — Manufacturer; 01-M01: https://www.fda.gov/drugs/guidance-compliance-regulatory-information/wuxi-sta-pharmaceutical-co-ltd-3032023

- **SRC-038** — Manufacturer; 01-M01: https://sta.wuxiapptec.com/wuxi-sta-passes-the-first-ema-drug-product-pre-approval-inspection-at-its-wuxi-city-site/

- **SRC-039** — Manufacturer; 01-M01: https://tides.wuxiapptec.com/services-solutions/peptide/peptide-cmc/api/

- **SRC-040** — Manufacturer; 01-M01: https://tides.wuxiapptec.com/wuxi-apptec-triples-peptide-manufacturing-capacity-and-launches-the-new-taixing-api-manufacturing-site/

- **SRC-041** — Manufacturer; 01-M01: https://www.federalregister.gov/documents/2026/06/10/2026-11571/notice-of-availability-of-designation-of-chinese-military-companies

- **SRC-042** — Manufacturer; 01-M01: https://law.justia.com/cases/federal/district-courts/district-of-columbia/dcdce/1:2026cv02069/293402/25/

- **SRC-043** — Manufacturer; 01-M01: https://www.wuxiapptec.com/news/wuxi-news/wuxi-apptecs-sta-subsidiary-opens-new-campus-in-changzhou

- **SRC-044** — Manufacturer; 01-M01: https://job.lzu.edu.cn/html/22/article/2021/26785.html

- **SRC-045** — Manufacturer; 01-M01: https://www.taixing.gov.cn/zwgk/xxgk/qt/art/2026/art_36ffc717d971456e810a5c5f09c3cab5.html

- **SRC-046** — Manufacturer; 01-M01: https://www.fda.gov/inspections-compliance-enforcement-and-criminal-investigations/inspection-classification-database

- **SRC-047** — Manufacturer; 01-M01: https://tides.wuxiapptec.com/services-solutions/peptide/peptide-cmc/analytical/

- **SRC-048** — Manufacturer; 01-M01: https://officialsite-static.wuxiapptec.com/upload/ANNOUNCEMENT_FOR_PRELIMINARY_INJUNCTION_2e0a0bc090.pdf

- **SRC-049** — Manufacturer; 01-M01: https://tides.wuxiapptec.com/facility/taixing-china/

- **SRC-050** — Manufacturer; 01-M01: https://tides.wuxiapptec.com/facility/wuxi-city-china/

- **SRC-051** — Manufacturer; 02-M02: http://static.cninfo.com.cn/finalpage/2026-04-30/1225262826.PDF

- **SRC-052** — Manufacturer; 02-M02: http://star.sse.com.cn/star/en/marketdata/snapshot/c/5547483.shtml

- **SRC-053** — Manufacturer; 02-M02: https://www.accessdata.fda.gov/scripts/SDA/sdDetailNavigation.cfm?sd=srolist&id=587C873A8EF03E9EE06346F0E10A144F&rownum=1997

- **SRC-054** — Manufacturer; 02-M02: https://www.allsino.com/en/index.html

- **SRC-055** — Manufacturer; 02-M02: https://www.sinopep.com/cdmo-services/formulation/

- **SRC-056** — Manufacturer; 02-M02: https://www.fda.gov/media/85138/download

- **SRC-057** — Manufacturer; 02-M02: https://www.sinopep.com/cdmo-services/regulatory-affairs/

- **SRC-058** — Manufacturer; 02-M02: https://www.csrc.gov.cn/csrc/c101928/c7603410/content.shtml

- **SRC-059** — Manufacturer; 02-M02: https://www.medtideinc.com/tc/CompanyNews/info.aspx?itemid=318

- **SRC-060** — Manufacturer; 02-M02: https://www.medtideinc.com/tc/companynews/info.aspx?itemid=319

- **SRC-061** — Manufacturer; 02-M02: http://www.csrc.gov.cn/csrc/c100090/c1519459/1519459/files/%E5%8F%91%E8%A1%8C%E4%BA%BA%E5%8F%8A%E4%BF%9D%E8%8D%90%E6%9C%BA%E6%9E%84%E5%85%B3%E4%BA%8E%E5%8F%91%E8%A1%8C%E6%B3%A8%E5%86%8C%E7%8E%AF%E8%8A%82%E5%8F%8D%E9%A6%88%E6%84%8F%E8%A7%81%E8%90%BD%E5%AE%9E%E5%87%BD%E7%9A%84%E5%9B%9E%E5%A4%8D.pdf

- **SRC-062** — Manufacturer; 02-M02: https://www.sinopep.com/cdmo-services/capacity/

- **SRC-063** — Manufacturer; 02-M02: https://www.sinopep.com/frequently-asked-questions/

- **SRC-064** — Manufacturer; 02-M02: https://www.pmda.go.jp/files/000240884.xlsx

- **SRC-065** — Manufacturer; 02-M02: https://www.accessdata.fda.gov/cms_ia/importalert_189.html

- **SRC-066** — Manufacturer; 02-M02: https://www.accessdata.fda.gov/cms_ia/importalert_1174.html

- **SRC-067** — Manufacturer; 03-M03: https://pdf.dfcfw.com/pdf/H2_AN202604291821715619_1.PDF?t=1782816592078

- **SRC-068** — Manufacturer; 03-M03: https://www.hybio.com/subsidiary/

- **SRC-069** — Manufacturer; 03-M03: https://www.nmpa.gov.cn/directory/web/nmpa//xxgk/ggtg/ypggtg/ypgmprzh/ypgmprzhgg/ypgmpshj/20190115000001188.html

- **SRC-070** — Manufacturer; 03-M03: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=2100ec49-57b2-4330-ab5f-057ce9b7e4d0

- **SRC-071** — Manufacturer; 03-M03: https://projects.propublica.org/rx-inspector/facilities/3011090684/

- **SRC-072** — Manufacturer; 03-M03: https://pdf.dfcfw.com/pdf/H2_AN202111191529958067_1.pdf

- **SRC-073** — Manufacturer; 03-M03: https://www.gov.br/anvisa/pt-br/composicao/diretoria-colegiada/reunioes-da-diretoria/votos-dos-circuitos-deliberativos-1/2025/cd-0660-2025-voto.pdf

- **SRC-074** — Manufacturer; 03-M03: https://projects.propublica.org/rx-inspector/facilities/3016069760/

- **SRC-075** — Manufacturer; 03-M03: https://www.nmpa.gov.cn/directory/web/nmpa/xxgk/ggtg/ypggtg/ypgmprzh/ypgmprzhgg/ypgmpshj/20181119000001285.html

- **SRC-076** — Manufacturer; 03-M03: https://cima.aemps.es/cima/publico/detalle.html?nregistro=84867

- **SRC-077** — Manufacturer; 03-M03: https://www.hybio.com/peptide-drug-development/

- **SRC-078** — Manufacturer; 03-M03: https://www.hybio.com/crdmo-services/

- **SRC-079** — Manufacturer; 03-M03: https://www.fda.gov/news-events/press-announcements/fda-approves-first-generic-once-daily-glp-1-injection-lower-blood-sugar-patients-type-2-diabetes

- **SRC-080** — Manufacturer; 03-M03: https://www.fda.gov/inspections-compliance-enforcement-and-criminal-investigations/inspection-basics/inspection-classifications

- **SRC-081** — Manufacturer; 03-M03: https://www.nmpa.gov.cn/directory/web/nmpa/zwfw/sdxx/sdxxyp/yppjfb/20230129155130147.html

- **SRC-082** — Manufacturer; 03-M03: https://www.nmpa.gov.cn/directory/web/nmpa/zwfw/sdxx/sdxxyp/yppjfb/20230202160812103.html

- **SRC-083** — Manufacturer; 03-M03: https://www.nmpa.gov.cn/zwfw/sdxx/sdxxyp/yppjfb/20260701155655187.html?type=pc&m=

- **SRC-084** — Manufacturer; 03-M03: https://www.hybio.com/zh/notice/announcement-on-the-wholly-owned-subsidiary-obtaining-the-austral/

- **SRC-085** — Manufacturer; 03-M03: http://notice.10jqka.com.cn/api/pdf/e224e819098f4d2c_1744976591/%E7%BF%B0%E5%AE%87%E8%8D%AF%E4%B8%9A%EF%BC%9A%E5%85%B3%E4%BA%8E%E5%90%91%E9%9F%A9%E5%9B%BD%E9%A3%9F%E5%93%81%E8%8D%AF%E5%93%81%E5%AE%89%E5%85%A8%E5%A4%84%E6%8F%90%E4%BA%A4%E6%9B%BF%E5%B0%94%E6%B3%8A%E8%82%BD%E5%8E%9F%E6%96%99%E8%8D%AF%E7%99%BB%E8%AE%B0%E7%9A%84%E5%85%AC%E5%91%8A.pdf

- **SRC-086** — Manufacturer; 03-M03: https://www.hybio.com/news/hybio-pharmaceutical-s-longhua-headquarters-r-d-center-laboratory-passes-fda-inspection-again-with-zero-deficiencies/

- **SRC-087** — Manufacturer; 03-M03: https://www.accessdata.fda.gov/CMS_IA/importalert_1186.html

- **SRC-088** — Manufacturer; 03-M03: https://disc.static.szse.cn/disc/disk03/finalpage/2023-08-14/0f7f53c8-77df-40f7-a9b9-6cc601875520.PDF

- **SRC-089** — Manufacturer; 03-M03: http://changchun.customs.gov.cn/shenzhen_customs/zfxxgk15/4956195/4956283/4962908/4972922/4972944/6586472/index.html

- **SRC-090** — Manufacturer; 03-M03: https://www.hybio.com/news/good-news-hybio-pharmaceutical-completes-official-nmpa-registration-for-tirzepatide-api/

- **SRC-091** — Manufacturer; 03-M03: https://www.hybio.com/news/good-news-hybio-pharmaceutical-completes-official-nmpa-registration-of-semaglutide-api/

- **SRC-092** — Manufacturer; 04-M04: https://www.kgi.com.hk/en/-/media/files/kgishk/pdf/ipoprospectus/hkipo_03880.pdf

- **SRC-093** — Manufacturer; 04-M04: https://cpcscientific.com/medtide-inc-cpc-scientifics-parent-company-debuts-on-hong-kong-stock-exchange/

- **SRC-094** — Manufacturer; 04-M04: https://projects.propublica.org/rx-inspector/facilities/3004518843/

- **SRC-095** — Manufacturer; 04-M04: https://hbw.citeline.com/-/media/pmbi-old-site/supporting-documents/pharmasia-news/2012/june/warning-letter--chinese-peptide-co.pdf

- **SRC-096** — Manufacturer; 04-M04: https://www.medtideinc.com/en/CompanyNews/info.aspx?itemid=327

- **SRC-097** — Manufacturer; 04-M04: https://newsfile.moomoo.com/public/NN-PersistNoticeAttachment/7781/20260330/12078527-0.PDF

- **SRC-098** — Manufacturer; 04-M04: https://cpcscientific.com/locations/

- **SRC-099** — Manufacturer; 04-M04: https://www.nmpa.gov.cn/directory/web/nmpa/xxgk/ggtg/ypggtg/ypgmprzh/ypgmprzhgg/ypgmpgjj/20100114165101245.html

- **SRC-100** — Manufacturer; 04-M04: https://www.businesswire.com/news/home/20260805297284/en/CPC-Scientific-Announces-U.S.-FDA-Pre-License-Inspection-PLI-Successfully-Completed-at-Its-Hangzhou-cGMP-Manufacturing-Facility-for-Hepcludex-API-Establishing-a-Proven-Track-Record-Under-the-Stringent-BLA-Pathway

- **SRC-101** — Manufacturer; 04-M04: https://static.propublica.org/fda-inspection-documents/483s/2024-10801%2F240010163_enc2_320.pdf

- **SRC-102** — Manufacturer; 04-M04: https://cpcscientific.com/custom-peptide-synthesis/cgmp-peptide-manufacturing/capacity/

- **SRC-103** — Manufacturer; 04-M04: https://cpcscientific.com/custom-peptide-synthesis/cgmp-peptide-manufacturing/quality/

- **SRC-104** — Manufacturer; 04-M04: https://www.fda.gov/news-events/press-announcements/fda-approves-first-treatment-chronic-hepatitis-delta-virus-hdv-infection

- **SRC-105** — Manufacturer; 04-M04: https://www.fda483s.com/fdadocs/chinese-peptide-company-hangzhou-china/

- **SRC-106** — Manufacturer; 04-M04: https://cpcscientific.com/cpc-scientifics-tirzepatide-api-successfully-secures-us-fda-dmf-filing/

- **SRC-107** — Manufacturer; 04-M04: https://cpcscientific.com/cpc-scientifics-gmp-manufacturing-facility-passes-german-inspection/

- **SRC-108** — Manufacturer; 04-M04: https://www.ema.europa.eu/en/medicines/human/EPAR/hepcludex

- **SRC-109** — Manufacturer; 04-M04: https://www.medtideinc.com/en/companynews/info.aspx?itemid=328

- **SRC-110** — Manufacturer; 04-M04: https://www.fda.gov/news-events/press-announcements/fda-launches-green-list-protect-americans-illegal-imported-glp-1-drug-ingredients

- **SRC-111** — Manufacturer; 05-M05: https://extranet.who.int/prequal/medicines/active-pharmaceutical-ingredient/whoapi-361-oxytocin

- **SRC-112** — Manufacturer; 05-M05: https://extranet.who.int/prequal/medicines/active-pharmaceutical-ingredient/whoapi-423-carbetocin

- **SRC-113** — Manufacturer; 05-M05: https://extranet.who.int/prequal/medicines/rh083

- **SRC-114** — Manufacturer; 05-M05: https://cdsco.gov.in/opencms/resources/UploadCDSCOWeb/2018/UploadInternationalCell/WC%20-0549%20-Piramal.pdf

- **SRC-115** — Manufacturer; 05-M05: https://www.fda.gov/media/185578/download

- **SRC-116** — Manufacturer; 05-M05: https://www.business-standard.com/markets/capital-market-news/piramal-pharma-gains-after-receiving-eir-for-turbhe-facility-from-usfda-125051200714_1.html

- **SRC-117** — Manufacturer; 05-M05: https://www.health.gov.za/wp-content/uploads/2026/02/Current-Master-Health-Product-List-6-Feb-2026.xlsx

- **SRC-118** — Manufacturer; 05-M05: https://www.piramalpharmasolutions.com/facilities/peptide-api-development-and-manufacturing-turbhe

- **SRC-119** — Manufacturer; 05-M05: https://ppl-da-website-new-afd-endpoint-bgd4d0c9egf9g2eq.a01.azurefd.net/media/documents/Annual-Report-FY-2025-26.pdf

- **SRC-120** — Manufacturer; 05-M05: https://www.piramalpharmasolutions.com/facilities/sterile-injectables-development-and-manufacturing-lexington

- **SRC-121** — Manufacturer; 05-M05: https://www.business-standard.com/markets/capital-market-news/piramal-pharma-gets-eir-for-lexington-facility-from-us-fda-126041300272_1.html

- **SRC-122** — Manufacturer; 05-M05: https://extranet.who.int/prequal/sites/default/files/whopar_files/RH083part6v2_1.pdf

- **SRC-123** — Manufacturer; 05-M05: https://www.piramalpharmasolutions.com/resources/blogs/cost-effective-synthesis-of-complex-cyclic-peptides

- **SRC-124** — Manufacturer; 05-M05: https://www.prnewswire.com/news-releases/piramal-pharma-solutions-expands-peptide-api-facility-with-advanced-spray-drying-suite-302842218.html

- **SRC-125** — Manufacturer; 05-M05: https://www.prnewswire.com/news-releases/piramal-pharmas-fy2026-annual-report-showcases-global-scale-innovation-led-growth-and-sustainability-milestones-302819498.html

- **SRC-126** — Manufacturer; 05-M05: https://www.pharmamanufacturing.com/industry-news/news/55271230/fda-hits-piramal-pharmas-api-plant-in-india-with-form-483-for-deficiencies

- **SRC-127** — Manufacturer; 06-M06: https://vbshilpa.com/pdf/Annual-report-results-2025-2026.pdf

- **SRC-128** — Manufacturer; 06-M06: https://vbshilpa.com/annual-reports.php

- **SRC-129** — Manufacturer; 06-M06: https://www.vbshilpa.com/locations.php

- **SRC-130** — Manufacturer; 06-M06: https://www.vbshilpa.com/pdf/Shilpa%20Pharma%20Lifesciences%20Limited,%20Received%20CEP%20from%20EDQM%20for%20API,%20Desmopressin.pdf

- **SRC-131** — Manufacturer; 06-M06: https://www.vbshilpa.com/pdf/Shilpa%20Pharma%20Lifesciences%20Limited,%20Received%20CEP%20from%20EDQM%20for%20API,%20Octreotide.pdf

- **SRC-132** — Manufacturer; 06-M06: https://www.vbshilpa.com/pdf/Shilpa%20Pharma%20Lifesciences%20Limited,%20Unit-1,%20Received%20EIR%20from%20USFDA.pdf

- **SRC-133** — Manufacturer; 06-M06: https://www.vbshilpa.com/pdf/Shilpa%20Pharma%20Lifesciences%20Ltd,%20Unit%20II,%20Raichur,%20Karnataka%20has%20cleared%20PMDA%20Japan,%20GMP%20inspection.pdf

- **SRC-134** — Manufacturer; 06-M06: https://www.vbshilpa.com/pdf/Shilpa%20Pharma%20Lifesciences%20Limited,%20Unit%202,%20Raichur,%20Karnataka%20has%20cleared%20the%20ANVISA-Brazil%20GMP%20inspection.pdf

- **SRC-135** — Manufacturer; 06-M06: https://www.vbshilpa.com/pdf/Europe%20GMP%20Approval%20of%20Shilpa%20Medicare%20Ltd.%20Unit%204,%20Jadcherla,%20Telangana..pdf

- **SRC-136** — Manufacturer; 06-M06: https://www.fda.gov/inspections-compliance-enforcement-and-criminal-investigations/warning-letters/shilpa-medicare-limited-607877-10092020

- **SRC-137** — Manufacturer; 06-M06: https://shilpapharma.com/capabilities/

- **SRC-138** — Manufacturer; 06-M06: https://shilpapharma.com/peptide-manufacturers/

- **SRC-139** — Manufacturer; 06-M06: https://vbshilpa.com/peptides-gmp.php

- **SRC-140** — Manufacturer; 06-M06: https://www.biopharminternational.com/view/shilpa-medicare-launches-hybrid-cdmo-dcat-week-2025

- **SRC-141** — Manufacturer; 06-M06: https://vbshilpa.com/peptides-non-gmp-services.php

- **SRC-142** — Manufacturer; 06-M06: https://shilpapharma.com/analytical-services/

- **SRC-143** — Manufacturer; 06-M06: https://www.edqm.eu/en/databases

- **SRC-144** — Manufacturer; 06-M06: https://www.sahpra.org.za/registered-health-products/

- **SRC-145** — Manufacturer; 06-M06: https://www.vbshilpa.com/press-releases.php

- **SRC-146** — Manufacturer; 06-M06: https://www.vbshilpa.com/peptides-generic.php

- **SRC-147** — Manufacturer; 06-M06: https://www.accessdata.fda.gov/drugsatfda_docs/nda/2024/215179Orig1s000OtherActionLtrs.pdf

- **SRC-148** — Manufacturer; 07-M07: https://peptistar.com/company/outline/

- **SRC-149** — Manufacturer; 07-M07: https://info.gbiz.go.jp/hojin/ichiran?hojinBango=5120901038915

- **SRC-150** — Manufacturer; 07-M07: https://www.peptidream.com/en/company/history/

- **SRC-151** — Manufacturer; 07-M07: https://contents.xj-storage.jp/xcontents/45870/0f4e7954/5cfb/4ea6/97e3/9737ca27ce47/140120260216562906.pdf

- **SRC-152** — Manufacturer; 07-M07: https://peptistar.com/en/news/20241111-2/

- **SRC-153** — Manufacturer; 07-M07: https://peptistar.com/en/news/20250326-2/

- **SRC-154** — Manufacturer; 07-M07: https://peptistar.com/en/news/20250417-2/

- **SRC-155** — Manufacturer; 07-M07: https://peptistar.com/en/service/peptide/

- **SRC-156** — Manufacturer; 07-M07: https://peptistar.com/en/technology/

- **SRC-157** — Manufacturer; 07-M07: https://peptistar.com/en/facility/manufacturing1/

- **SRC-158** — Manufacturer; 07-M07: https://peptistar.com/en/facility/manufacturing2/

- **SRC-159** — Manufacturer; 07-M07: https://peptistar.com/en/service/

- **SRC-160** — Manufacturer; 07-M07: https://www.fda.gov/drugs/pharmaceutical-quality-resources/inspection-enforcement-resources

- **SRC-161** — Manufacturer; 07-M07: https://www.ema.europa.eu/en/human-regulatory-overview/research-development/compliance-research-development/good-manufacturing-practice/eudragmdp-database

- **SRC-162** — Manufacturer; 07-M07: https://peptistar.com/en/facility/headquarters/

- **SRC-163** — Manufacturer; 07-M07: https://peptistar.com/en/facility/

- **SRC-164** — Manufacturer; 07-M07: https://www.sumitomo-chem.co.jp/english/news/detail/20241111e.html

- **SRC-165** — Manufacturer; 07-M07: https://peptistar.com/en/service/analysis/

- **SRC-166** — Manufacturer; 07-M07: https://peptistar.com/en/service/cmc/

- **SRC-167** — Manufacturer; 07-M07: https://peptistar.com/en/

- **SRC-168** — Manufacturer; 07-M07: https://peptistar.com/en/technology/microwave/

- **SRC-169** — Manufacturer; 07-M07: https://peptistar.com/en/technology/stagps/

- **SRC-170** — Manufacturer; 07-M07: https://peptistar.com/en/technology/syncsol/

- **SRC-171** — Manufacturer; 07-M07: https://peptistar.com/en/technology/hilic/

- **SRC-172** — Manufacturer; 07-M07: https://peptistar.com/en/technology/mcsgp/

- **SRC-173** — Manufacturer; 07-M07: https://peptistar.com/en/technology/lyophilization/

- **SRC-174** — Manufacturer; 07-M07: https://www.asahi-kasei.com/news/2026/e260625

- **SRC-175** — Manufacturer; 07-M07: https://peptistar.com/en/quality/

- **SRC-176** — Manufacturer; 08-M08: https://www.ajibio-pharma.com/news-post/ajinomoto-althea-and-omnichem-combine-to-form-ajinomoto-bio-pharma-services-reflecting-a-collective-range-of-services-offered-to-the-bio-pharma-industry/

- **SRC-177** — Manufacturer; 08-M08: https://www.ajioligos.com/en/about/specialists-in-oligonucleotides/

- **SRC-178** — Manufacturer; 08-M08: https://www.ajinomoto.com/aboutus/global_network

- **SRC-179** — Manufacturer; 08-M08: https://www.ajibio-pharma.com/contact-us/japan/

- **SRC-180** — Manufacturer; 08-M08: https://www.ajibio-pharma.com/cdmo-services/oligo-peptide-synthesis/ajiphase-synthesis/

- **SRC-181** — Manufacturer; 08-M08: https://www.ajibio-pharma.com/cdmo-services/oligo-peptide-synthesis/

- **SRC-182** — Manufacturer; 08-M08: https://www.ajibio-pharma.com/cdmo-services/oligo-peptide-synthesis/solid-phase-synthesis/

- **SRC-183** — Manufacturer; 08-M08: https://www.ajibio-pharma.com/news-post/genedesign-joins-ajinomoto-bio-pharma-services-and-opens-oligonucleotide-api-development-center/

- **SRC-184** — Manufacturer; 08-M08: https://www.ajibio-pharma.com/news-post/first-commercial-drug-manufactured-via-ajinomoto-bio-pharma-services-ajiphase-technology-receives-fda-approval/

- **SRC-185** — Manufacturer; 08-M08: https://www.fda.gov/drugs/cder-foia-electronic-reading-room/ajinomoto-company-inc-02212025

- **SRC-186** — Manufacturer; 08-M08: https://projects.propublica.org/rx-inspector/facilities/3002806336/

- **SRC-187** — Manufacturer; 08-M08: https://www.ajibio-pharma.com/news-post/ajinomoto-co-inc-to-sell-its-entire-equity-stake-in-ajinomoto-althea-a-us-based-aseptic-fill-finish-cdmo/

- **SRC-188** — Manufacturer; 08-M08: https://www.ajinomoto.co.jp/company/en/presscenter/press/detail/g2016_12_09.html

- **SRC-189** — Manufacturer; 08-M08: https://www.ajibio-pharma.com/news-post/ajinomoto-bio-pharma-services-and-olon-s-p-a-form-strategic-partnership-to-advance-large-scale-peptide-and-protein-manufacturing/

- **SRC-190** — Manufacturer; 08-M08: https://ajibio-pharma.ajinomoto.com/corynex/

- **SRC-191** — Manufacturer; 08-M08: https://www.fda.gov/about-fda/fda-commissioner/ajinomoto-althea-inc-dba-ajinomoto-bio-pharma-services-san-diego-ca-483-issued-01162023

- **SRC-192** — Manufacturer; 08-M08: https://www.ajibio-pharma.com/dedication-to-quality/quality-management/

- **SRC-193** — Manufacturer; 08-M08: https://www.ajibio-pharma.com/dedication-to-quality/regulatory-excellence/

- **SRC-194** — Manufacturer; 08-M08: https://www.ajibio-pharma.com/cdmo-services/oligo-peptide-synthesis/product-quality-analytical-testing/

- **SRC-195** — Manufacturer; 08-M08: https://www.ajibio-pharma.com/cdmo-services/oligo-peptide-synthesis/process-development/

- **SRC-196** — Manufacturer; 09-M09: https://kind.krx.co.kr/external/2026/05/15/002059/20260515004562/11013.htm

- **SRC-197** — Manufacturer; 09-M09: https://www.fda.gov/drugs/drug-master-files-dmfs/list-drug-master-files-dmfs

- **SRC-198** — Manufacturer; 09-M09: https://www.fda.gov/media/192069/download?attachment

- **SRC-199** — Manufacturer; 09-M09: https://hlbpep.co.kr/kor/customer/notice.php?m=v&idx=1606

- **SRC-200** — Manufacturer; 09-M09: https://hlbpep.co.kr/kor/customer/notice.php?m=v&idx=1548&pNo=1&code=notice

- **SRC-201** — Manufacturer; 09-M09: http://hlbpep.co.kr/

- **SRC-202** — Manufacturer; 09-M09: https://kind.krx.co.kr/external/2026/07/10/000747/20260710001647/00636.htm

- **SRC-203** — Manufacturer; 09-M09: https://www.accessdata.fda.gov/scripts/sda/sdDetailNavigation.cfm?sd=srolist&id=587C873A8BC53E9EE06346F0E10A144F&rownum=1160

- **SRC-204** — Manufacturer; 09-M09: https://hlbpep.co.kr/kor/company/location.php

- **SRC-205** — Manufacturer; 09-M09: https://hlbpep.co.kr/kor/customer/notice.php?m=v&idx=1398&pNo=2&code=notice

- **SRC-206** — Manufacturer; 09-M09: https://kind.krx.co.kr/external/2024/03/20/000736/20240320003693/11011.htm

- **SRC-207** — Manufacturer; 09-M09: https://kind.krx.co.kr/external/2026/03/12/001283/20260312003157/00591.htm

- **SRC-208** — Manufacturer; 09-M09: https://hlbpep.co.kr/eng/peptides/generic.php

- **SRC-209** — Manufacturer; 09-M09: http://hlbpep.co.kr/kor/company/history.php

- **SRC-210** — Manufacturer; 09-M09: https://www.mfds.go.kr/eng/brd/m_19/view.do?seq=70331&srchFr=&srchTo=&srchWord=&srchTp=&itm_seq_1=0&itm_seq_2=0&multi_itm_seq=0&company_cd=&company_nm=&page=4

- **SRC-211** — Manufacturer; 09-M09: https://kind.krx.co.kr/external/2025/04/14/000262/20250414000741/00636.htm

- **SRC-212** — Manufacturer; 10-M10: https://www.fda.gov.tw/TC/siteListContent.aspx?sid=2067&id=3723

- **SRC-213** — Manufacturer; 10-M10: https://www.fda.gov.tw/TC/siteListContent.aspx?sid=2067&id=39453

- **SRC-214** — Manufacturer; 10-M10: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=707a64ef-964e-44a3-8a0f-fcc2eb5b1af2

- **SRC-215** — Manufacturer; 10-M10: https://www.accessdata.fda.gov/scripts/sda/sdDetailNavigation.cfm?sd=srolist&id=587C873A70A23E9EE06346F0E10A144F&rownum=1133

- **SRC-216** — Manufacturer; 10-M10: https://www.scinopharm.com/investor_document-detail/352/

- **SRC-217** — Manufacturer; 10-M10: https://www.globalkeysolutions.net/records/fda_inspections/scinopharm-taiwan-ltd/ffdf6876-5ab7-4104-85ad-a0fd0f722d4f

- **SRC-218** — Manufacturer; 10-M10: https://www.fda.gov/media/184915/download

- **SRC-219** — Manufacturer; 10-M10: https://www.fda.gov/media/184916/download

- **SRC-220** — Manufacturer; 10-M10: https://www.scinopharm.com/news-detail/115/

- **SRC-221** — Manufacturer; 10-M10: https://findbiz.nat.gov.tw/fts/company/16130161

- **SRC-222** — Manufacturer; 10-M10: https://findbiz.nat.gov.tw/fts/factory/08/94A00015

- **SRC-223** — Manufacturer; 10-M10: https://www.scinopharm.com/investor-detail/major-shareholders/

- **SRC-224** — Manufacturer; 10-M10: https://www.scinopharm.com/brand/20/

- **SRC-225** — Manufacturer; 10-M10: https://www.scinopharm.com/products-detail/56/

- **SRC-226** — Manufacturer; 10-M10: https://www.scinopharm.com/products-detail/commercialAPI/

- **SRC-227** — Manufacturer; 10-M10: https://www.scinopharm.com/news-detail/137/

- **SRC-228** — Manufacturer; 10-M10: https://www.scinopharm.com/products-detail/54/

- **SRC-229** — Manufacturer; 10-M10: https://www.scinopharm.com/news-detail/117/

- **SRC-230** — Manufacturer; 10-M10: https://www.scinopharm.com/news-detail/139/

- **SRC-231** — Manufacturer; 10-M10: https://www.scinopharm.com/download/57/

- **SRC-232** — Manufacturer; 10-M10: http://jp.scinopharm.com/upload/download/files/220170913154210.PDF

- **SRC-233** — Manufacturer; 10-M10: https://www.scinopharm.com/about/

- **SRC-234** — Manufacturer; 10-M10: https://www.globalkeysolutions.net/records/fda_inspections/scinopharm-taiwan-ltd/7044bf7c-e911-4e7c-84ce-056f5f8b6169

- **SRC-235** — Manufacturer; 10-M10: https://www.scinopharm.com/products-detail/60/

- **SRC-236** — Manufacturer; 10-M10: https://www.scinopharm.com/solutions/QC/

- **SRC-237** — Manufacturer; 10-M10: https://www.scinopharm.com/download/80/

- **SRC-238** — Laboratory; 01-L01: https://www.sgsgroup.com.cn/zh-cn/news/2025/01/sgs-shanghai-health-science-laboratory

- **SRC-239** — Laboratory; 01-L01: https://www.sgsgroup.com.cn/-/media/sgscorp/documents/corporate/third-party-documents/1-cma20171021.cdn.en-CN.pdf

- **SRC-240** — Laboratory; 01-L01: https://www.sgsgroup.com.cn/en-cn/our-company/about-sgs/sgs-in-china

- **SRC-241** — Laboratory; 01-L01: https://www.prnasia.com/story/462074-1.shtml

- **SRC-242** — Laboratory; 01-L01: https://www.sgsonline.com.cn/case/article/detail-7335.html

- **SRC-243** — Laboratory; 01-L01: https://www.sgs.com/en/office-directory/sgs-china-shanghai-kangqiao-road-building-5-office

- **SRC-244** — Laboratory; 01-L01: https://www.sgs.com/en-us/news/2023/03/announcing-the-grand-opening-of-sgss-new-bioanalytical-laboratory-in-shanghai-china

- **SRC-245** — Laboratory; 01-L01: https://www.etics.org/eu_std_db/tl_scope_std.php?id_tl=124&id_products_category=6&s=1

- **SRC-246** — Laboratory; 01-L01: https://las.cnas.org.cn/LAS_FQ/publish/suspendCancellationQuery.jsp?orgType=L

- **SRC-247** — Laboratory; 01-L01: https://manufacturingchemist.com/sgs-expands-extractables-and-leachables-testing-capabilities-at-its-shanghai-facility--130532

- **SRC-248** — Laboratory; 01-L01: https://www.sgsgroup.com.cn/en-cn/services/forced-degradation

- **SRC-249** — Laboratory; 01-L01: https://www.fiercepharma.com/pharma-asia/sgs-life-science-services-completes-new-laboratories-at-its-shanghai-facility

- **SRC-250** — Laboratory; 01-L01: https://www.sgsgroup.com.cn/en-cn/services/container-closure-integrity-testing

- **SRC-251** — Laboratory; 02-L02: https://info.gbiz.go.jp/hojin/ichiran?hojinBango=9120001058249

- **SRC-252** — Laboratory; 02-L02: https://www.pmda.go.jp/files/000277257.xlsx

- **SRC-253** — Laboratory; 02-L02: https://www.pmda.go.jp/review-services/gmp-qms-gctp/gmp/0025.html

- **SRC-254** — Laboratory; 02-L02: https://www.pmda.go.jp/english/about-pmda/0004.html

- **SRC-255** — Laboratory; 02-L02: https://www.eurofins.com/ja-jp/biopharma-services/biopharma-product-testing/biopharmaceutical-characterization/

- **SRC-256** — Laboratory; 02-L02: https://cdnmedia.eurofins.com/apac/media/603045/001_company-profile_flyer.pdf

- **SRC-257** — Laboratory; 02-L02: https://www.eurofins.com/ja-jp/biopharma-services/biopharma-product-testing/instrumentation/

- **SRC-258** — Laboratory; 02-L02: https://www.eurofins.com/ja-jp/biopharma-services/biopharma-product-testing/qc-testing/

- **SRC-259** — Laboratory; 02-L02: https://www.eurofins.com/ja-jp/biopharma-services/biopharma-product-testing/

- **SRC-260** — Laboratory; 02-L02: https://www.eurofins.com/ja-jp/biopharma-services/biopharma-product-testing/microbiological-testing/

- **SRC-261** — Laboratory; 02-L02: https://www.eurofins.com/ja-jp/biopharma-services/biopharma-product-testing/stability-testing/

- **SRC-262** — Laboratory; 02-L02: https://www.eurofins.com/ja-jp/biopharma-services/biopharma-product-testing/qc-testing/cci/

- **SRC-263** — Laboratory; 02-L02: https://www.eurofins.com/ja-jp/biopharma-services/biopharma-product-testing/impurity-testing/extractables-and-leachables/

- **SRC-264** — Laboratory; 02-L02: https://www.fda.gov/media/177453/download

- **SRC-265** — Laboratory; 02-L02: https://www.eurofins.com/en/biopharma-services/news/eurofins-analytical-science-laboratories-expands-biologics/

- **SRC-266** — Laboratory; 02-L02: https://www.eurofins.com/ja-jp/biopharma-services/biopharma-product-testing/reference-standard-management/

- **SRC-267** — Laboratory; 03-L03: https://vimta.com/contact-us/

- **SRC-268** — Laboratory; 03-L03: https://extranet.who.int/prequal/quality-control-labs/india-vimta-genome-v

- **SRC-269** — Laboratory; 03-L03: https://extranet.who.int/prequal/sites/default/files/whopir_files/WHOPIR_VimtaLabs_18-20January2023_0.pdf

- **SRC-270** — Laboratory; 03-L03: https://extranet.who.int/prequal/medicines/prequalified/quality-control-labs

- **SRC-271** — Laboratory; 03-L03: https://vimta.com/wp-content/uploads/2026/05/USFDA-EIR-communication_2023.pdf

- **SRC-272** — Laboratory; 03-L03: https://vimta.com/wp-content/uploads/2026/05/EMA-Certificate.pdf

- **SRC-273** — Laboratory; 03-L03: https://vimta.com/industries/drug-discovery-development/testing/

- **SRC-274** — Laboratory; 03-L03: https://vimta.com/industries/testing/mass-spec-analysis-peptides-proteins/

- **SRC-275** — Laboratory; 03-L03: https://vimta.com/extractables-leachables-studies/

- **SRC-276** — Laboratory; 03-L03: https://www.sahpra.org.za/wp-content/uploads/2022/06/SAHPGL-LIC-01-Guide-On-How-to-Apply-for-A-Licence-To-Manufacture_DN.pdf

- **SRC-277** — Laboratory; 03-L03: https://nabl-india.org/nabl/index.php?c=publicaccredationdoc&m=index&docType=misc&per_page=75

- **SRC-278** — Laboratory; 03-L03: https://vimta.com/industries/drug-discovery-development/cgmp-analytical-services/

- **SRC-279** — Laboratory; 03-L03: https://vimta.com/industries/cgmp-analytical-services/api-analysis/

- **SRC-280** — Laboratory; 03-L03: https://vimta.com/about-us/quality-management-system/

- **SRC-281** — Laboratory; 03-L03: https://extranet.who.int/prequal/news/new-who-public-inspection-reports-whopirs-published-90

- **SRC-282** — Laboratory; 04-L04: https://cdn.intertek.com/www-intertek-com/media/countrysites/2026/Intertek-Pharmaceutical-Services-India-Brochure.pdf

- **SRC-283** — Laboratory; 04-L04: https://cdn.intertek.com/www-intertek-com/dms-legacy/Intertek%20Terms%20%20Conditions%20of%20Business%20-%20INDIA.pdf

- **SRC-284** — Laboratory; 04-L04: https://www.iasonline.org/ias_certificate/tl-1217/

- **SRC-285** — Laboratory; 04-L04: https://www.iasonline.org/wp-content/uploads/2023/12/TL-1217-Cert-New.pdf

- **SRC-286** — Laboratory; 04-L04: https://bycsa.co/wp-content/uploads/2025/07/Acreditacion_de_laboratorio.pdf

- **SRC-287** — Laboratory; 04-L04: https://dst.gov.in/sites/default/files/Certified%20Test%20Facilities%20withTest%20Items%20and%20Test%20Systems%2031072026.pdf

- **SRC-288** — Laboratory; 04-L04: https://dst.gov.in/ngcma

- **SRC-289** — Laboratory; 04-L04: https://www.intertek.com/india/

- **SRC-290** — Laboratory; 04-L04: https://www.intertek.com/contact/asiapacific/india/

- **SRC-291** — Laboratory; 04-L04: https://economictimes.indiatimes.com/company/intertek-india-private-limited/U74220DL1997PTC202243

- **SRC-292** — Laboratory; 04-L04: https://fda.maharashtra.gov.in/sections/

- **SRC-293** — Laboratory; 04-L04: https://www.linkedin.com/posts/intertek_biosciences-intertekindia-environmental-activity-7431793756342947840-sQbe

- **SRC-294** — Laboratory; 04-L04: https://nabcb.qci.org.in/iaf-ilac-mla/iaf-intertek-india-pvt-ltd-mdqms033/

- **SRC-295** — Laboratory; 04-L04: https://nabl-india.org/nabl/uploads/List_of_Suspended_Labs_as_on_14-05-2026.pdf

- **SRC-296** — Laboratory; 04-L04: https://nabl-india.org/nabl/uploads/List_of_Suspended_Labs_as_on_02-12-2025.pdf

- **SRC-297** — Laboratory; 04-L04: https://www.intertek.com/pharmaceutical/biopharmaceuticals/peptide-analysis-and-formulation/

- **SRC-298** — Laboratory; 04-L04: https://www.intertek.com/pharmaceutical/analysis/qc/

- **SRC-299** — Laboratory; 04-L04: https://www.intertek.com/pharmaceutical/analysis/extractables-leachables/

- **SRC-300** — Laboratory; 04-L04: https://www.intertek.com/pharmaceutical/analysis/method-development-validation/

- **SRC-301** — Laboratory; 04-L04: https://www.sahpra.org.za/wp-content/uploads/2022/09/SAHPGL-INSP-04_v5Guidelines-for-Preparation-of-Site-Master-File.pdf
