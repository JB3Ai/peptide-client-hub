# George Asian Peptide Supplier Due-Diligence Evidence Pack

**Decision date:** 20 August 2026

This evidence pack supports supplier prequalification for regulated therapeutic peptide sourcing into South Africa. It contains the discovery universe, ten manufacturer dossiers, four independent-laboratory dossiers, the synthesized decision report, structured manufacturer and laboratory datasets, a 301-URL source register, and the working qualification tracker.

The material is a **public-evidence screen only**. It does not establish that any company, site, product, method, batch or route is fully compliant, safe, approved by SAHPRA, or suitable for purchase. Full qualification remains product-, site-, process-, method-, dossier-, batch- and transport-lane-specific and requires primary document verification, South African regulatory assessment, risk-based audits, validated testing, quality and technical agreements, and formal cross-functional approval.

## Pack structure

| Folder or file | Purpose |
|---|---|
| `discovery.md` | Selection rationale and initial universe of ten manufacturers and four laboratories. |
| `manufacturers/` | One detailed cited dossier per manufacturer/CDMO. |
| `laboratories/` | One detailed cited dossier per independent laboratory/site. |
| `final/Asian_Peptide_Manufacturers_Laboratories_and_Supply_Chain_Due_Diligence.md` | Synthesized decision report. |
| `final/George_Asian_Peptide_Supplier_Qualification_Tracker.xlsx` | Live scoring, RFI, 90-day qualification, risk/no-go and source-tracking workbook. |
| `final/asian_peptide_manufacturers.csv` | Structured manufacturer screen. |
| `final/asian_peptide_laboratories.csv` | Structured laboratory screen. |
| `final/source_register.csv` | Complete URL register for the discovery and fourteen dossiers. |

The workbook and report should be treated as controlled working documents. Replace public-evidence scores with verified confidential evidence and audit outcomes before any final supplier decision.
